function notDone() {
    alert("This link doesn't go anywhere!")
}

function helloThere() {
        document.getElementById("project-1").innerHTML += "<p>Hello There</p>"
    
}

function cycleColor() {

    color = document.getElementById("project-2").style.backgroundColor

    if(color == "red"){
        color = "blue"
        document.getElementById("project-2").style.backgroundColor = color;
    }
    else{
        color = "red"
        document.getElementById("project-2").style.backgroundColor = color;
    }
      
}

