import React from 'react';
import MainRouter from './components/MainRouter'

function App() {
  return (
    <div className="App">
      <MainRouter></MainRouter>
    </div>
  );
}

export default App;
