const express = require('express');
const router = express.Router();
const {userSchema, usersModel} = require('../../../db/mongoose-models/user-model')
const db = require('../../../db/dal-mongoose')

/* GET users listing. */
router.get('/', function(req, res, next) {
  
  let dbObject = new db.DbObject(usersModel,)

  db.findAll(dbObject)
  .then(result => {
    res.json(result)
  })
  .catch(error => {
    res.json(error)
  })
});

router.post('/', function(req, res, next) {

  let dbObject = new db.DbObject(usersModel, req.body)

  db.create(dbObject)
  .then(result => {
    console.log(result)
    res.json(result)
  })
  .catch(error => {
    console.log(error)
    res.json(error)
  })
})

router.delete('/:id', function(req, res, next) {

  let dbObject = new db.DbObject(usersModel, null, req.params.id)

  db.del(dbObject)
  .then(result => {
    console.log(result)
    res.json(result)
  })
  .catch(error => {
    console.log(error)
    res.json(error)
  })
})

module.exports = router;
