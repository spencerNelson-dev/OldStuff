const mongoose = require('mongoose')

const Schema = mongoose.Schema;

const usersSchema = new Schema({
    firstName: {
        type: String, // This could be shortened to firstName: String,
        require: true
    }, 
    lastName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }

});

usersSchema.methods.fullName = function () {

    return `${this.firstName} ${this.lastName}`
}

module.exports.usersModel = mongoose.model('Users', usersSchema, 'users')
module.exports.usersSchema = usersSchema
