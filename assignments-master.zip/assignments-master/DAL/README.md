Stretch Your Thoughts: Answer the following questions: 

Why are we using Promises here?

We use promises to make sure our actions concerning the database are fulfilled before we move on in our program.

What benefits are there for breaking out these functions into their own resource?

Seperation of concerns. We can now more easily switch databases if we wanted. It is also easier to follow the logic and find bugs

What other functionality could you foresee leveraging this separation of concerns technique with?

The express generator seperates the views and routes. So our view, our server logic, our database logic, our api consumption could all be seperated.
