const MongoClient = require('mongodb').MongoClient;
const ObjectId = require('mongodb').ObjectID

let client 

// Connect to db
function connect(objConnect) {

    const uri = "mongodb+srv://data_user:ChemicalE1@cluster0-caj9q.mongodb.net/test?retryWrites=true&w=majority";

    client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    return client.connect()
    .then(connection => {

        console.log("making db connection...")

        objConnect.usersCollection = connection.db("helio").collection("users")

        return true

    })
    .catch( error => {

        console.log(error)

        throw new Error(error)

    })

} // end of function connect

// Close db
function close(){

    client.close()
}

// POST - Create
function create(objCreate) {

    return objCreate.usersCollection.insertOne(objCreate.doc)  
}

// GET - Read One
function readOne(objRead) {

    return objRead.usersCollection.findOne({_id: ObjectId(objRead.id)})
}

// GET - Read All
function readAll(objRead){



    return new Promise( (reslove, reject) => {

        objRead.usersCollection.find({}).toArray(function (err, result) {

            if(err) {
                reject(err)
            }
            reslove(result)
        })    
    }) 
}

// PATCH - Update
function update(objUpdate) {

    delete objUpdate.doc._id

    let newValues = {$set: objUpdate.doc}

    return objUpdate.usersCollection.updateOne({_id: ObjectId(objUpdate.id)}, newValues)

}

// PUT - Replace
function replace(objReplace){

    // Remove the id from the replacement document
    delete objReplace.doc._id

    return objReplace.usersCollection.replaceOne({_id: ObjectId(objReplace.id)},objReplace.doc)

}

// can't use delete as a function name 
// because it is a js keyword
function del(objDelete) {

    return objDelete.usersCollection.deleteOne({_id: ObjectId(objDelete.id)})
}

module.exports.connect = connect
module.exports.close = close
module.exports.create = create
module.exports.readOne = readOne
module.exports.readAll = readAll
module.exports.update = update
module.exports.replace = replace
module.exports.del = del