import React from 'react'
import {Link} from 'react-router-dom'
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
    root: {
      '& > *': {
        margin: theme.spacing(1),
      },
      'background-color': 'gray'
    },
  }));

export default function SignIn () {
    const classes = useStyles();

    let [message, setMessage] = React.useState("Hello!")
    let [firstName, setFirstName] = React.useState("")
    let [lastName, setLastName] = React.useState("")

    const onClickHandler = () => {

        setMessage(`Hello ${firstName} ${lastName}`)
    }

    const onChangeHandler = (event) => {

        switch (event.target.name) {
            case 'firstName':
                setFirstName(event.target.value)
                break
            case 'lastName':
                setLastName(event.target.value)
                break
            default:
                break
        }
    }
    
    return (
        <div className={classes.root}>
        <h1>Sign In</h1>
        
        First Name: <input onChange={onChangeHandler}  name='firstName' value={firstName}/><br/>
        Last Name: <input onChange={onChangeHandler} name='lastName' value={lastName}/><br/>

        <Button variant="contained" color="primary" onClick={onClickHandler}>Submit!</Button>

         <p>{message}</p>

         <Link to='/'>Home</Link>
        </div>
    )
}