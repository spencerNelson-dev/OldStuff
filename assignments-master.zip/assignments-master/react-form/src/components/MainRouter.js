import React from 'react'
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import SignIn from './SignIn'
import Welcome from './Welcome'

export default function MainRouter () {

    return (

        <Router>
            <Switch>
                <Route path='/signin' component={SignIn}></Route>

                <Route path='/' component={Welcome}></Route>
            </Switch>
        </Router>

    )
}