import React from 'react'
import {Link} from 'react-router-dom'

export default function Welcome () {

    return (

        <div>
            <h1>Welcome Friend!</h1>
            <Link to='/signin'> Sign In</Link>
        </div>
    )
}