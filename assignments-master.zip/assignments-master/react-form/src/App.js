import React from 'react';
import './App.css';
import MainRouter from './components/MainRouter';

function App() {
  return (
    <div className="App">
      <MainRouter></MainRouter>
    </div>
  );
}

export default App;
