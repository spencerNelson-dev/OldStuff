Stretch your Thoughts:

### What techniques can you use to help you translate raw HTML into React?
React does that for us with JSX. 

### In what way can you think about the HTML building blocks that will help you build React forms?
They can be used in about the same way as regular HTML.

### What resources are shared between HTML and React? 
The properties are shared for the HTML tags.