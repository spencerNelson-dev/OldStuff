let dbUsers = require('./db/arrayData')

let fetch = require("node-fetch")

let URL = "http://localhost:3002/api/v1"


// GET
function printUsers(id="") {
    let myUsers = fetch(`${URL}/usersv1/${id}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }})
        .then(httpResult => httpResult.json())
        .then(result => console.log(result))

}

// POST
async function addUser(URL, user) {
    let body = JSON.stringify(user);

    let newUser = await fetch(`${URL}/usersv1`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: body
        })
        .then(httpResult => httpResult.json())
        .then(result => console.log(result))

    return newUser
}

// DELETE
function deleteUser(url, item) {
    return fetch(`${url}/usersv1/${item}`, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(result => console.log(result));
        
}

// PATCH
function updateUser(url, item, updates) {
    let body = JSON.stringify(updates)

    return fetch(`${url}/usersv1/${item}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: body
        
    })
    .then(httpResult => httpResult.json())
    .then(result => console.log(result))
}

let newUser = {
    firstName: "afda",
    lastName: "eads",
    password: "12345",
    email: "bob2@fake.com"
}


printUsers()

addUser(URL, newUser)

deleteUser(URL, 0)

updateUser(URL, 0, {password: "newPass"})

printUsers(0)

