What RESTful functions are you going to use to complete this assignment?

The RESTful functions we used are:

Create with POST
Read with GET
Update with PUT and PATCH
Delete with DELETE