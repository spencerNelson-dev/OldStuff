let users = [{
    id: 0,
    firstName: "Spencer",
    lastName: "Nelson",
    password: "1234",
    email: "fake@fake.com"
  
  }]

  module.exports.users = users