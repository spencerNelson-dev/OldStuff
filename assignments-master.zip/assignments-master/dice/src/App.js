import React from 'react';
import './App.css';


const Die = (props) => {
  const [result, setResult] = React.useState('')

  return (
    <React.Fragment>
    {`Dice with ${props.sides} sides`}
    <button onClick={() => {setResult( Math.floor(Math.random() * (props.sides)) + 1)}}>roll</button>
    result: {`${result}`}
  </React.Fragment>
  )
}

function App() {

  const [dice, setDice] = React.useState([4,6,8,10,12,20])
  const [sides, setSides] = React.useState(0)

  const newDieHandler = () => {

    let currentDice = [...dice]
    
    currentDice.push(sides)

    setDice(currentDice)

    console.log(dice)

  }

  const deleteHandler = (event, index) => {

    let newDice = [...dice]

    newDice.splice(index,1)

    setDice(newDice)

  }

  const updateHandler = (event) => {

    setSides(Number(event.target.value))
  }

  React.useEffect(() => {

}, [])

  return (
    <div>
      <ul>
        {
          dice.map((die, index) => {
            return (
              <li key={index}>
                <button onClick={(event) => {deleteHandler(event, index)}}>Delete</button> <Die sides={die}/> 
              </li>
            )
          })
        }
      </ul>
      <div>
        Add dice with: <input type='number'
                              name='numberOfSides'
                              value={sides}
                              onChange={updateHandler}></input> sides.

        <button onClick={newDieHandler}>Add</button>

      </div>
    </div>
  );
}

export default App;
