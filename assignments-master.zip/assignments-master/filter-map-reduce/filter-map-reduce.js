const fs = require('fs');


// get content from file
var contents = fs.readFileSync("src_data_senators.json");

// Define to JSON file
var jsonContent = JSON.parse(contents);

console.log(jsonContent)


