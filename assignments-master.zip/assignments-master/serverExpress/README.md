1. What else can you do with Node Packages?

Node packages can do all sorts of things. The better question is what can't you do. Node packages allow the sharing of code between programmers. If you are looking for a package to solve a problem, you will find it.

2. What else can you do with Express? 

Express allows you to serve functions instead of static pages. This provides a greater degree of flexablitliy and control.


3. What other technologies could you use instead of Express?

Other server packages inclue Hapi, Sails.js, Koa and Strapi.

4. How is hosting in Express different than how you've hosted before?

We run express on our local machine. This means that both the browser and server are on the same machine. If we hosted through gitpages or other online hosting serveses, our files are on their machines and they are running the server software.