let express = require('express')

// Create our express app
let app = express()

//app.set('view engine', 'ejs')
app.use(express.static('public'))

app.get('/profile',(req,res) => {

   res.render('profile',{ 
       data: "This is a test",
       data2: "This is another test",
       button: {name: "myname"}
    })
})

let server = app.listen(3000, () => {})