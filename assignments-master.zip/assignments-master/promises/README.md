Answer the following questions to help stretch your thoughts: 

What is a Promise? 
    A promise is an object that has a value property and several methods including then(), catch(), finally().

How do we use Promises? 
    If we want to contiue our program while waiting for another process we can use a promise. For example if we send a request to a server we can contiune until that promise is fulfilled. This allows our code to be asycronous.

What are the benefits of using Promises? 
    The main benefit of using promises is that we do not have to deal with callback hell. Our code will be layed out vertically instead of horizontally. It is easier to follow.