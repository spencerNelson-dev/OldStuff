// Import fs
let fs = require('fs')

function getBeers() {

    // Here our function getBeers returns a promise
    return new Promise((resolve, reject) => {

        // We attempt to read file beers.txt, utf8 encoded passing a call back function
        fs.readFile("beers.txt",'UTF-8', (error, data) => {

            // if there is an error, pass it into the reject method
            // of the promise object
            if(error != null){
                reject(error)

            // else pass data into the resolve method
            } else {
                resolve(data)
            }
        }) // end of readFile

    }) // end of promise

} // end of getBeers


// here we add getBeers to exports
module.exports = getBeers