// We impot getBeers from fileio.js
let getBeers = require('./fileio')

// We sent the main function as async to force it to return a promise
async function main() {

    // Calling getBeers returns a promise
    getBeers()

        // .then() will return the value property of the promise which is the data
        .then(myResult => {
            
            return JSON.parse(myResult) // this returns a Promise object
        })

        // We acess the value of the preceeding promise which is the objBeers array
        .then(objBeers => {

            // We log out the first entry of objBeers
            console.log(objBeers[0])

            // We throw an Error this will be caught by .catch()
            throw new Error("This is a bad error")
        })

        // catches any error thrown through the promise chain
        .catch((error) => { 

            // This will log the new error "This is a bad error"
            console.log(error)
        })

        // finally runs regardless if an error or not
        .finally(() => { 
            console.log("Finally Run")
        })

    // here we use the await keyword to make sure that
    // this getBeers call resolves before moving on
    let newBeers = await getBeers()

    // These console.logs will run after the await function
    console.log("New Beers")
    console.log(JSON.parse(newBeers)[1])
    console.log("End of program")
    
}// end of async function


// Here we call main() so our program runs
main()

//Our console will read the 1st element of the beers array or 2nd depending
//on which completes first.
