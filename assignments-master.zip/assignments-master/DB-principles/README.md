DB -Principles

1.	What is a database? And why is it necessary.
a.	A database is a place where data is stored. The memory in a database is non-volatile.
b.	A database is necessary to have more perinate data. The data stored in arrays or objects in our files, is destroyed and recreated every time we stop running or run our program. A database will keep that data on a “hard-drive” so even if the power is off, the data still exists.
2.	What can be stored in a database?
a.	Any data you want, objects, pictures, text, code, … you name it.
3.	What types of databases are there?
a.	There are relational databases, such as SQL and non-relational databases such as mongoDB. There are also graph databases
4.	Why would I use one over the other?
a.	Different databases have different features that might be advantageous to your application. Relational databases are more ridged and require more pre-planning. Non-relational databases are less ridged and don’t need as much design.
5.	What is a query?
a.	A query a is a request for data or information from a database.
6.	What is encryption? And why is it important at a database level?
a.	Encryption is a way to hide information. Passwords are often encrypted so that others cannot use them to gain unauthorized access to accounts. It is important for databases for the same reason. We would not want our users data to be exposed.
7.	What is object permanence?
a.	Object permanence is knowing something is there without seeing it.
8.	Where can your database live?
a.	Databases can live on any computer. Your local machine can hold a database, and companies offer databases as services













Practice Building a Data Model

{
	“$schema”: “ http://json-schema.org/draft-04/schema#”
	“title”: “User”,
	“description”: “User’s information”,
	“type”: “object”,
	“properties” :
 {
	“firstName”:{
		“description”: “A user’s first name”
		“type”: ”string”
			}
	“lastName”: {
		“description”: “A user’s last name”
		“type”: ”string”
			}
	“email”: {
		“description”: “A user’s email”
		“type”: ”string”
			}
	“password”: {
		“description”: “A user’s password”
		“type”: ”string”
			}
},
“required”: [“firstName”, “lastName”, “email”, “password”]
}





