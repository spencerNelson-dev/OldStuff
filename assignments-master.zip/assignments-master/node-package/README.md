1. According to the npm website : 

"A package is a file or directory that is described by a package.json file. A package must contain a package.json file in order to be published to the npm registry."

"A module is any file or directory in the node_modules directory that can be loaded by the Node.js require() function.

To be loaded by the Node.js require() function, a module must be one of the following:

A folder with a package.json file containing a "main" field.
A folder with an index.js file in it.
A JavaScript file."

source: https://docs.npmjs.com/about-packages-and-modules

2. To publish an npm package follow the directions found here:

https://docs.npmjs.com/creating-and-publishing-unscoped-public-packages