let ca = require("color-away")

const FORMAT_BLINK = 4
const BACKGROUND_WHITE = 16
const FONT_BLUE = 5

let message = "Hello World"

console.log(message)

ca.log([FORMAT_BLINK], [BACKGROUND_WHITE], [FONT_BLUE], message);