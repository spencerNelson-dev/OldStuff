// Solving fizzBuzz using a for loop
function fizzBuzzFor() {
    for (let index = 1; index <= 100; index++) {

        let output = ""

        if (index % 3 == 0) { output += "Fizz" }
        if (index % 5 == 0) { output += "Buzz" }

        if (output == "") { output = index }

        console.log(output)
    }
}

// using a while loop
function fizzBuzzWhile(){

    let index = 1

    while (index <= 100) {

        let output = ""

        if (index % 3 == 0) { output += "Fizz" }
        if (index % 5 == 0) { output += "Buzz" }

        if (output == "") { output = index }

        console.log(output)

        index++
    }
}

// using do while
function fizzBuzzDo(){

    let index = 1

    let output = ""

    do {
        if (index % 3 == 0) { output += "Fizz" }
        if (index % 5 == 0) { output += "Buzz" }

        if (output == "") { output = index }

        console.log(output)

        index++

    } while (index <=100) {
        if (index % 3 == 0) { output += "Fizz" }
        if (index % 5 == 0) { output += "Buzz" }

        if (output == "") { output = index }

        console.log(output)

        index++

    }
}

// Test the functions
fizzBuzzDo()
fizzBuzzWhile()
fizzBuzzFor()