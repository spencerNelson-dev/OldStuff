// Example of a class component
import React from 'react'
import { Link } from 'react-router-dom'
import { uriBase , api } from '../const'

export default class Login extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            name: props.initialMessage,
            userName: "",
            password: "",
            loggedIn: "Not Logged In"
        }

        // bind our onClickHandler
        this.onClickHandler = this.onClickHandler.bind(this)
        this.onChangeHandler = this.onChangeHandler.bind(this)

    } // end of constructor

    onClickHandler() {

        let body = {
            userName: this.state.userName,
            password: this.state.password
        }

        fetch(`${uriBase}${api}/users/login`,{
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        })
        .then(httpResponse => {
            if (!httpResponse.ok){
                throw new Error("Couldn't Send Login")
            }

            return httpResponse.json()
        })
        .then(user => {

            if(user.hasOwnProperty("firstName")){

                this.setState({loggedIn: "Logged In"})
            } else {

                this.setState({loggedIn: "Not Logged In"})
            }

        })
        .catch(error => {
            console.log(error)
        })
    }

    onChangeHandler(event) {

        // here we can handle multiple event handlers
        // the event.target.name takes the name property
        // of the item that had an event
        this.setState({[event.target.name]: event.target.value})

        //console.log(this.state)
    }

    render() {

        return (
            <div>
                <h1>{this.state.name}</h1>
                <h2>{this.state.loggedIn}</h2>

                <div>
                User Name: 
                <input onChange={this.onChangeHandler} name='userName' value={this.state.userName}/><br/>
                Password: 
                <input onChange={this.onChangeHandler} name='password' value={this.state.password}/>
                </div>

                <div>
                <button onClick={this.onClickHandler} >Login</button>
                </div>

                <div>
                <Link to='/signup'>Sign Up</Link><br/>
                <Link to='/users'>Users</Link>
                </div>


            </div>

        )
    }
}