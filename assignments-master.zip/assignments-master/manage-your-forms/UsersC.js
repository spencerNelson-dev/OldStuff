import React from 'react'
import {uriBase, api} from '../const'

export default class UsersC extends React.Component {
    constructor(props){
        super(props)

        this.state = {
            users: []
        }

        this.refresh = this.refresh.bind(this)
    }

    refresh() {

        //'http://localhost:3001/API/v1/users'
        fetch(`${uriBase}${api}/users`,{
            method: 'GET',
            //mode: "no-cors",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"
            }
        })
        .then(httpResult => {
            if (!httpResult.ok) {
                throw new Error("Bad response")
            }

            return httpResult.json()
        })
        .then(response => {
            console.log(response)
            this.setState({users: response})
        })
        .catch(error=>{
            console.log(error)
        })
    }

    componentDidMount() {

        this.refresh()
    }

    render() {

        return (
            <div>
                <h1>UsersC</h1>
                <ul>
                    {
                       this.state.users.map((user, index) => {
                           return (
                                <li key={index}>{user.firstName} {user.lastName}</li>
                           )
                       }) 
                    }
                </ul>

            </div>
        )
    }
}