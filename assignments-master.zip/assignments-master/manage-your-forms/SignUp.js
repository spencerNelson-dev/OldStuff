// Example of a function component
import React from 'react'
import { Link } from 'react-router-dom'
import { uriBase, api} from '../const'

export default function SignUp(props) {

    // setting up our state
    let [message, setMessage] = React.useState(props.initialMessage)
    let [firstName, setFirstName] = React.useState("")
    let [lastName, setLastName] = React.useState("")
    let [userName, setUserName] = React.useState("")
    let [password, setPassword] = React.useState("")

    const onClickHandler = (event) => {

        event.preventDefault()

        let formData = new FormData()
        formData.append("firstName", firstName)
        formData.append("lastName", lastName)
        formData.append("userName", userName)
        formData.append("password", password)



        fetch(`${uriBase}${api}/users/signup`, {
            method: "POST",
            headers: {
                "Content-Type": "multipart/form-data"
            },
            body: formData
        })
        .then(httpRequest => {
            if(!httpRequest.ok){
                throw new Error("Couldn't add user")
            }

            return httpRequest.json()
        })
        .then(user => {
            // TODO
            // Handle user
            console.log(user)

            setMessage(`Sign up success for ${user.firstName}`)
        })
        .catch(error => {
            console.log(error)
        })

        
    }

    const onChangeHandler = (event) => {

        switch (event.target.name) {
            case 'firstName':
                setFirstName(event.target.value)
                break
            case 'lastName':
                setLastName(event.target.value)
                break
            case 'userName':
                setUserName(event.target.value)
                break
            case 'password':
                setPassword(event.target.value)
                break
            default:
                break
        }
    }

    return (
        <div>
            <h1>{message}</h1>

            <form>
                First Name: <input onChange={onChangeHandler} name='firstName' value={firstName} /><br/>
                Last Name: <input onChange={onChangeHandler} name='lastName' value={lastName} /><br/>
                User Name: <input onChange={onChangeHandler} name='userName' value={userName} /><br/>
                Password: <input onChange={onChangeHandler} name='password' value={password} /><br/>
                <input onClick={onClickHandler} type='submit'></input>
            </form>
            <Link to='/'>Home</Link>

        </div>
    ) // end of return
}