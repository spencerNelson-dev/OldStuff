import React from 'react'
import {uriBase, api} from '../const'
import { Link } from 'react-router-dom'

export default function UsersF (props) {

    const [users, setUsers] = React.useState([])

    const refresh = () => {

        fetch(`${uriBase}${api}/users`,{
            method: 'GET',
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"
            }
        })
        .then(httpResult => {
            if (!httpResult.ok) {
                throw new Error("Bad response")
            }

            return httpResult.json()
        })
        .then(response => {
            console.log(response)
            setUsers(response)
        })
        .catch(error=>{
            console.log(error)
        })
    }


    React.useEffect( () => {

        refresh()
    }, [])

    return (
        <div>
        <h1>UsersF</h1>
        <ul>
            {
               users.map((user, index) => {
                   return (
                        <li key={index}>{user.firstName} {user.lastName}</li>
                   )
               }) 
            }
        </ul>

        <div>
            <Link to='/'>Home</Link>
        </div>

    </div>

    )
}