### What is State Management?
State managment is managing the state, meaning the data, of the react comonents.

### In what way can you think React leverages good State Management principles? 
React makes it so that for the most part components' state is self-contained. If states need to be shared react provides a context or the use of Redux store.

### What is the difference React and JavaScript? What is the same? 
React has shortcuts that are interperted by babel. React also uses JSX tags to mimic HTML. Everything else is the same as JavaScript.
