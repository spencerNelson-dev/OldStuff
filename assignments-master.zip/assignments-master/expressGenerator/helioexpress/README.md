What type of resources can you host with Express?
    You can host html, ejs, js, css, pictures and any other resource you could host with any other hosting service.

What are the benefits of using a View Engine over using Vanilla technologies?
    View engines allow us to pass information into the view. It allows us to create templates that will be filled out by javascript.

Why does the Express Generator split up the functionality into so many files?
    This allows for seperation of concerns. Each file does a specific thing, so our code is more managable.