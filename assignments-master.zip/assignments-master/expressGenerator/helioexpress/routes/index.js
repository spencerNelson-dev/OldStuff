var express = require('express');
var router = express.Router();
let fetch = require('node-fetch')



/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

/* GET new page. */

router.get('/new', async (req, res, next) => {
  console.log(req.query)
  data = { text: req.query.words };
  let body = JSON.stringify(data);

  url = 'https://api.funtranslations.com/translate/sindarin.json'

  let result = await fetch(url, {
    method: "POST",
    body: body,
    headers: {
      "Content-Type": "application/json"
    }
    })
    .then(httpResult => httpResult.json())

    // if the api sends an empty object, set the translated property to ""
    if(!result.hasOwnProperty("contents")){
      result.contents = {translated: ""}
    }

  res.render('newPage', { myTranslation: result.contents.translated })
})


module.exports = router;
