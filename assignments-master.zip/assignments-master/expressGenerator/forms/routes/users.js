var express = require('express');
var router = express.Router();

//User array
let users = [{
  id: 0,
  firstName: "Spencer",
  lastName: "Nelson",
  password: "1234",
  email: "fake@fake.com"

}]

/* add user routes */
//display user form
router.get('/add', function (req, res, next) {

  res.render('add-user', {response: ""})
});

router.post('/add', function (req, res, next) {
  let user = req.body
  user.id = users.length
  users.push(user)
  res.render('add-user', {response: "User added!"})
});

// login form routes
// display user form
router.get('/login', function (req, res, next) {

  res.render('login',{message: ""})
})

// catch login post
router.post('/login', function (req, res, next) {

  let message = "Invalid Login"

  let foundUser = users.find((user) => {

    let rtnval = false

    if (req.body.email.toLowerCase() == user.email.toLocaleLowerCase()) {

      rtnval = true
    }

    return rtnval
    })

  if (foundUser !== undefined){

    if(foundUser.password === req.body.password){

      message = `${foundUser.firstName} ${foundUser.lastName} has logged in.`
    }

  }

  res.render('login', {message})

})

// delete
router.get('/delete', function (req, res, next) {

  res.render('delete-user', {users, response: ""})
})

router.post('/delete', function (req, res, next) {

  let response = "Not a valid user"

  let userIndex = users.findIndex( (user) => {

    let rtnval = false

    if (req.body.email.toLowerCase() == user.email.toLocaleLowerCase()) {

      rtnval = true
    }

    return rtnval

  })

  if (userIndex !== -1){

    foundUser = users[userIndex]

    if(foundUser.password === req.body.password){

      response = `${foundUser.firstName} ${foundUser.lastName} has been removed.`

      users.splice(userIndex, 1)
    }

  }

  res.render('delete-user',{users, response})
})

// forgot pass
router.get('/forgot', function (req, res, next) {

  res.render('forgot-pass', {response: ""})
})

router.post('/forgot', function (req, res, next) {

  let response = "Not a valid email."

  let foundUser = users.find((user) => {

    let rtnval = false

    if (req.body.email.toLowerCase() == user.email.toLocaleLowerCase()) {

      rtnval = true
    }

    return rtnval
    })

  if (foundUser !== undefined){

    response = `Your password is: ${foundUser.password}`
  }

  res.render('forgot-pass', {response})
})

// update
router.get('/update', function (req, res, next) {

  res.render('update-user',{users, user: ""})
})

router.post('/update', function (req, res, next) {

  let index = req.body.id

  let user = users[index]

  for (key in user){

    if (req.body[key] !== ""){

      user[key] = req.body[key]
    }
  }

  users[index] = user

  res.render('update-user',{users, user: JSON.stringify(user)})
});


module.exports = router;
