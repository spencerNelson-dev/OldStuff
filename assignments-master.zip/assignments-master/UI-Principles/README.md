### What is a User Interface? 
The means by which the user and a computer system interact, in particular the use of input devices and software.

### Explain the different between the User Experience and the User Interface.
User interface deals more with the input devices and software. User experince is the overall experience of a person using a product such as a website or computer application, especially in terms of how easy or pleasing it is to use.

### What is a Mock Up?  
"A mockup is a static wireframe with much more UI and visual details. If a wireframe is considered as the blueprint of a building, a mockup is similar to a real-life building model. It gives viewers a more realistic impression of how the final website/app will look like."
https://www.mockplus.com/blog/post/wireframe-mockup-prototype-selection-of-prototyping-tools

### Define Low & High Fidelity 
Low fidelity is where the fedelity of visual design, content and interactivity are low. It has only some of the visual attibutes, only key content elements and the interactivity can be simulated by a human. High fidelity is, of course, the opposite of lo-fi. High-fidelity prototypes appear and function as similar as possible to the actual product that will ship.

### Outline the benefits of using one 
The benifits of a hi-fi prototype are meaningful feedback, testibility of specific UI elements or interatctions and easy buy-in. Testers using a hi-fi proptotype will use have more realistic and natural interactions. It will also be easier to show to shareholders to sell you product.

### What is Mobile First Design? 
It is dessigning the mobile experience / UI before the others. "'Mobile first', as the name suggests, means that we start the product design from the mobile end which has more restrictions, then expand its features to create a tablet or desktop version."
https://medium.com/@Vincentxia77/what-is-mobile-first-design-why-its-important-how-to-make-it-7d3cf2e29d00

### Who should be in control of the User Interface? 
Everyone has some control, but the user should have the most say, as they will be using it.

### Define Reusable Components. 
Components that can be used across different projects without much editing.
