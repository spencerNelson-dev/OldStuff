self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "04946081f249d8d3f7dd64e61e9e4eee",
    "url": "/change/index.html"
  },
  {
    "revision": "7d679aaa1407725b3088",
    "url": "/change/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "52c73f1b0e8b1edea9de",
    "url": "/change/static/js/2.8b2ebb82.chunk.js"
  },
  {
    "revision": "0749163b59fbee32225059cb60c18af6",
    "url": "/change/static/js/2.8b2ebb82.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7d679aaa1407725b3088",
    "url": "/change/static/js/main.5a1bb3f3.chunk.js"
  },
  {
    "revision": "2e6a90f703191fb5e53d",
    "url": "/change/static/js/runtime-main.b0eab6c4.js"
  }
]);