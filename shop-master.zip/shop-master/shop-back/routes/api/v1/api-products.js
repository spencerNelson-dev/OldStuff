const express = require('express');
const router = express.Router();
const {productsModel} = require('../../../db/mongoose-models/product-model')
const db = require('../../../db/dal-mongoose')


// GET - get all products
router.get('/', function(req, res, next){

    let dbObject = new db.DbObject(productsModel)

    // find all products
    db.findAll(dbObject)
    .then(result => {

        // return the list of products
        res.json(result)
    })
    .catch(error => {

        console.log(error)
        // return an empty list if error
        res.json([])
    })
})

// POST - create a product
router.post('/', function(req, res, next){

    let dbObject = new db.DbObject(productsModel, req.body)

    db.create(dbObject)
    .then(result => {

        // return the created product
        res.json(result)
    })
    .catch(error => {

        console.log(error)
        // return the error message if not
        res.json(error.message)
    })
})

// PATCH - change the isActive property of a product
router.patch('/:id', function(req, res, next){
    
    let dbObject = new db.DbObject(productsModel, req.body, req.params.id)

    db.updateById(dbObject)
    .then(result => {

        // return the updated product
        res.json(result)
    })
    .catch(error => {

        console.log(error)

        // return the error message if not
        res.json(error.message)
    })

})

// PUT - replace the product
router.put('/:id', function(req, res, next){

    let dbObject = new db.DbObject(productsModel, req.body, req.params.id)

    
    db.replaceById(dbObject)
    .then(result => {

        // return the nModified
        res.json(result)
    })
    .catch(error => {

        console.log(error)

        // return the error message if not
        res.json(error.message)
    })
})

// DELETE - delete the product
router.delete('/:id', function(req, res, next){

    let dbObject = new db.DbObject(productsModel, null, req.params.id)

    db.del(dbObject)
    .then(result => {

        // sends back deleteCount
        res.json(result)
    })
    .catch(error => {

        console.log(error)

        // return the error message if not
        res.json(error.message)
    })

})




module.exports = router