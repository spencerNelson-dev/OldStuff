const mongoose = require('mongoose')
require('dotenv').config()

class DbObject {

    constructor(model, doc = null, id = null, search = null) {
        this.doc = doc,
            this.model = model,
            this.id = id,
            this.search = search
    }
}

function connect() {
    console.log("connecting")

    const uri = process.env.DB_CONNECTION_STRING

    return mongoose.connect(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        dbName: "shop"
    })
        .catch(error => {
            console.log(error)
        })
}

function close() {

    mongoose.connection.close()
}

function findAll(dbObject) {
    let rtnVal

    if (dbObject.model != null) {
        rtnVal = dbObject.model.find().exec()
    } else {
        rtnVal = new Promise().reject("Could not find")
    }

    return rtnVal

}

function findById(dbObject) {
    let rtnVal

    if (dbObject.model != null) {
        rtnVal = dbObject.model.find({ _id: dbObject.id }).exec()
    } else {
        rtnVal = new Promise().reject("Could not find")
    }

    return rtnVal
}

function updateById(dbObject) {
    let rtnVal

    if (dbObject.model != null) {
        rtnVal = dbObject.model.updateOne({ _id: dbObject.id }, dbObject.doc).exec()
    } else {
        rtnVal = new Promise().reject("Could not find")
    }

    return rtnVal
}

function replaceById(dbObject) {
    let rtnVal

    if (dbObject.model != null) {
        
        // upsert makes replaceOne act like PUT
        // if the id is not found then
        // a new document is created
        // Note: the id must be the same shape
        // as the mongoDB id or else it will not
        // make a new doc.
        rtnVal = dbObject.model.replaceOne({ _id: dbObject.id }, dbObject.doc, { upsert: true }).exec()
    } else {
        rtnVal = new Promise().reject("Could not find")
    }

    return rtnVal
}

function create(dbObject) {
    let rtnValue

    if (dbObject != null) {
        rtnValue = dbObject.model.create(dbObject.doc)
    } else {
        rtnValue = new Promise().reject("Could not Insert One")
    }

    return rtnValue
}

function del(dbObject) {
    let rtnValue

    console.log(dbObject)

    if (dbObject != null) {

        rtnValue = dbObject.model.deleteOne({ _id: dbObject.id }).exec()
    } else {
        rtnValue = new Promise().reject("Could not Delete")
    }

    return rtnValue
}

module.exports.DbObject = DbObject
module.exports.close = close
module.exports.findAll = findAll
module.exports.findById = findById
module.exports.updateById = updateById
module.exports.replaceById = replaceById
module.exports.connect = connect
module.exports.create = create
module.exports.del = del
