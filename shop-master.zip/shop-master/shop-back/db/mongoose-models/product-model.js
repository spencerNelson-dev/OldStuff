const mongoose = require('mongoose')

const Schema = mongoose.Schema;

const productsSchema = new Schema({
    name: {
        type: String,
        required: [true, 'No name entered.']
    },
    description: {
        type: String,
        default: "None"
    },
    quantity: {
        type: Number,
        required: [true, "No quantity entered."],
        min: [0, "negitive numbers not allowed"]
    },
    isActive: {
        type: Boolean,
        default: true
    }

});


module.exports.productsModel = mongoose.model('Products', productsSchema, 'products')
module.exports.productsSchema = productsSchema
