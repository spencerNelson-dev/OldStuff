This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Study Aid Application

This application will allow the user to create flash cards to help study any subject.

Each card has two sides:
    1. Term
    2. Definition

    The user should be able to "flip" the card over

    The user should be able to get the next card in the deck

    The user should be ablt to get the previous card in the deck

    The user should be able to shuffle the order of the deck.

The user should be able to:
    Create, Update and Delete cards and decks

The admin should be able to:
    Create, update and delete users
