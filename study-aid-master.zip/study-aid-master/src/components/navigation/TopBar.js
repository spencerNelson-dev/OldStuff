import React, { useState } from 'react';
import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import IconButton from '@material-ui/core/IconButton'
import MenuIcon from '@material-ui/icons/Menu'
import Button from '@material-ui/core/Button'
import Typography from '@material-ui/core/Typography'
import { makeStyles } from '@material-ui/core/styles'

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    menuButton: {
        marginRight: theme.spacing(2),
    },
    title: {
        flexGrow: 1,
    },
}));

function TopBar(props) {
    const classes = useStyles();

    //Temp state
    const [loggedIn, setLoggedIn] = useState(false)

    return (
        <div>
            <AppBar position="static">
                <Toolbar>
                    {
                        loggedIn ? (
                            <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
                                <MenuIcon />
                            </IconButton>
                        ) : (
                            null
                        )
                    }
                    <Typography variant="h3" className={classes.title}>
                        Study-Aid
          </Typography>
                    <Button onClick={() => {setLoggedIn(true)}} color="inherit">Login</Button>
                </Toolbar>
            </AppBar>
        </div>
    );
}

export default TopBar;