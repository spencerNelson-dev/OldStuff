import React from 'react';

function LandingPage(props) {
    return (
        <div>
            
        </div>
    );
}

export default LandingPage;


/*
The landing page should have the following information and actions

Login
Create Account


About the app

*/