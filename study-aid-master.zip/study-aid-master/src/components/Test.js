import React from 'react';
import TopBar from './navigation/TopBar'

function Test(props) {
    return (
        <div>
            <TopBar></TopBar>
            This is a test!
        </div>
    );
}

export default Test;